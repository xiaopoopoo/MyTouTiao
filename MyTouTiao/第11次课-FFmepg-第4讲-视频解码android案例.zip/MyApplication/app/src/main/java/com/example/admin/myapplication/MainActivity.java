package com.example.admin.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import java.io.File;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String rootPath = Environment.getExternalStorageDirectory()
                .getAbsolutePath();
        String inFilePath = rootPath.concat("/DreamFFmpeg/Test.mov");
        String outFilePath = rootPath.concat("/DreamFFmpeg/Test.yuv");

        //文件不存在我创建一个文件
        File file = new File(outFilePath);
        if (file.exists()){
            Log.i("日志：","存在");
        }else {
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        ffmepgDecodeVideo(inFilePath, outFilePath);
    }

    public native void ffmepgDecodeVideo(String inFilePath, String outFilePath);
}
